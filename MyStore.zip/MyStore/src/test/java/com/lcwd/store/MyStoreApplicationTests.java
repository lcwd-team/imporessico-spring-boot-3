package com.lcwd.store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
