package com.lcwd.store.entities;

public class Product {

}
