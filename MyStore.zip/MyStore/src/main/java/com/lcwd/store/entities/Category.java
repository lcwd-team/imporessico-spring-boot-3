package com.lcwd.store.entities;

public class Category {

}
