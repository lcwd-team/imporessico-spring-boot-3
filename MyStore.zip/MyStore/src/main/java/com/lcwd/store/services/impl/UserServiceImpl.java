package com.lcwd.store.services.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lcwd.store.dtos.UserDto;
import com.lcwd.store.entities.User;
import com.lcwd.store.services.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Override
	public UserDto addUser(UserDto userDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDto updateUser(UserDto user, int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDto getUser(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDto> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deletUser(int userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<UserDto> searchUser(String keywords) {
		// TODO Auto-generated method stub
		return null;
	}

}
